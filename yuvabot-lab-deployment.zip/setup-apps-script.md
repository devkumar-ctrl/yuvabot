# Google Apps Script Setup Guide

This guide will help you set up Google Apps Script to handle contact form submissions from your Yuvabot Lab website.

## 📋 Prerequisites

1. **Google Account** - You need a Google account to create Apps Script
2. **Google Sheets** - For storing form submissions
3. **Web App URL** - To connect your website to Apps Script

## 🚀 Step-by-Step Setup

### Step 1: Create Google Sheets

You need to create **two separate Google Sheets**:

#### Contact Form Sheet
1. Go to [Google Sheets](https://sheets.google.com)
2. Create a new spreadsheet
3. Name it "Yuvabot Lab Contact Form"
4. Copy the **Sheet ID** from the URL:
   ```
   https://docs.google.com/spreadsheets/d/14YjIkCiVp2kRYK1i2rR-YxHy662KuSjPjZs-EQQUTVY/edit
   ```
   The Sheet ID is: `14YjIkCiVp2kRYK1i2rR-YxHy662KuSjPjZs-EQQUTVY`

#### Enquiry Form Sheet
1. Create **another** new spreadsheet
2. Name it "Yuvabot Lab Business Enquiries"
3. Copy the **Sheet ID** from the URL:
   ```
   https://docs.google.com/spreadsheets/d/1BtWoJ5ucDkJxa0MFSN8MzzRc8-1T2YZRM0qfFkysX80/edit
   ```
   The Sheet ID is: `1BtWoJ5ucDkJxa0MFSN8MzzRc8-1T2YZRM0qfFkysX80`

### Step 2: Create Google Apps Script

1. Go to [Google Apps Script](https://script.google.com)
2. Click **"New Project"**
3. Name it: `Yuvabot Lab Contact Form Handler`
4. Delete the default code and paste the code from `google-apps-script.js`

### Step 3: Configure the Script

1. In the Apps Script editor, find this line:
   ```javascript
   const sheetId = 'YOUR_GOOGLE_SHEET_ID_HERE'; // Replace with your Sheet ID
   ```

2. Replace `'YOUR_GOOGLE_SHEET_ID_HERE'` with your actual Sheet ID from Step 1

3. Optional: Update the admin email address (already set to info@yuvabot.com):
   ```javascript
   const adminEmail = 'info@yuvabot.com'; // Admin email for notifications
   ```

### Step 4: Deploy as Web App

1. Click **"Deploy"** → **"New deployment"**
2. Select **"Web app"** as the type
3. Configure:
   - **Description**: `Yuvabot Lab Contact Form Handler`
   - **Execute as**: `Me`
   - **Who has access**: `Anyone` (important for public form submissions)
4. Click **"Deploy"**
5. **Copy the Web App URL** - it will look like:
   ```
   https://script.google.com/macros/s/DEPLOYMENT_ID/exec
   ```

### Step 5: Update Your Website Configuration

1. Create or update your `.env` file:
   ```bash
   # Add this line to your .env file
   APPS_SCRIPT_URL=https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/exec
   ```

2. Replace `YOUR_DEPLOYMENT_ID` with the ID from the web app URL

### Step 6: Test the Integration

1. Start your website server:
   ```bash
   npm start
   ```

2. Submit a test contact form at `http://localhost:3000`

3. Check your Google Sheet - the submission should appear automatically

## 🔧 Google Apps Script Code Explanation

### Main Function: `doPost(e)`
- Receives form data from your website
- Validates required fields
- Stores data in Google Sheets
- Sends confirmation email to admin
- Returns success/error response

### Data Structure
The script expects this JSON format:
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "phone": "+91 9876543210",
  "interest": "Cyber Security",
  "subject": "Training Inquiry",
  "message": "I am interested in your training programs",
  "newsletter": "Yes",
  "source": "Website Contact Form",
  "ip": "127.0.0.1",
  "userAgent": "Mozilla/5.0...",
  "timestamp": "2024-12-17T10:30:00.000Z",
  "requestId": "unique-request-id"
}
```

### Sheet Columns
The Google Sheet will have these columns:
- Timestamp
- Request ID
- Full Name, First Name, Last Name
- Email, Phone
- Interest, Subject, Message
- Newsletter subscription
- Source, IP Address, User Agent
- Status

## 🧪 Testing the Setup

### Test the Apps Script Directly
1. In Apps Script editor, run the `testScript()` function
2. Check the logs and your Google Sheet

### Test from Website
1. Submit the contact form
2. Check browser console for success/error messages
3. Verify data appears in Google Sheet
4. Check if admin email is received

## 🔒 Security Considerations

1. **Access Control**: The web app is set to "Anyone" for form submissions
2. **Input Validation**: Server-side validation prevents malicious data
3. **Rate Limiting**: Your website has rate limiting to prevent abuse
4. **Logging**: All submissions are logged for monitoring

## 🐛 Troubleshooting

### Common Issues:

1. **"Script not found" error**
   - Check that the deployment URL is correct
   - Ensure the script is deployed as a web app

2. **Data not appearing in Sheet**
   - Verify the Sheet ID is correct
   - Check that the sheet name is "Contact_Form"
   - Ensure the script has edit permissions for the Sheet

3. **Email not sending**
   - Check that you've set up the admin email address
   - Verify that the script has permission to send emails

4. **CORS errors**
   - Your server is configured to allow Google Apps Script domain
   - Check the `APPS_SCRIPT_URL` in your `.env` file

### Debug Steps:

1. Check Apps Script logs: **View → Logs**
2. Test the web app URL directly in browser
3. Check your website's server logs
4. Verify the Google Sheet permissions

## 📞 Support

If you encounter issues:
1. Check the Apps Script execution logs
2. Verify all configuration steps
3. Test with the provided test functions
4. Ensure proper permissions are granted

## 🔄 Updating the Script

To make changes:
1. Edit the code in Apps Script editor
2. Test your changes
3. Deploy a new version
4. Update the deployment URL in your `.env` file

## 📊 Monitoring

- Check your Google Sheet regularly for new submissions
- Monitor the Apps Script execution logs
- Set up email notifications for important submissions
- Review the admin dashboard at `/xyzadminsCybEr`
