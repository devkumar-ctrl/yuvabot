# Yuvabot Lab Website

A modern, responsive website for Yuvabot Lab Private Limited - Technology Education & Industrial Solutions.

## 🚀 Features

- **Modern Design**: Glassmorphism UI with animated 3D background
- **Responsive**: Mobile-first design with Tailwind CSS
- **Contact Forms**: Integrated with Google Apps Script for form handling
- **Career Portal**: Student and college registration systems
- **Resource Hub**: Blog, tutorials, and downloadable content
- **Dark/Light Mode**: Theme toggle functionality
- **SEO Optimized**: Semantic HTML and structured content

## 🛠️ Installation

1. **Clone or navigate to the project directory**
   ```bash
   cd /home/devkumar/Desktop/my\ tools/website
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Configure environment variables**

   Create a `.env` file in the root directory:
   ```bash
   # Server Configuration
   PORT=3000
   NODE_ENV=development

   # CORS Configuration (comma-separated origins)
   ALLOWED_ORIGINS=http://localhost:3000,http://127.0.0.1:3000,https://yourdomain.com

   # Google Apps Script Configuration
   # Replace with your actual Google Apps Script web app URL
   APPS_SCRIPT_URL=https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec

   # Email Service Configuration (optional - for future newsletter integration)
   # MAILCHIMP_API_KEY=your_mailchimp_api_key
   # MAILCHIMP_LIST_ID=your_list_id
   ```

4. **Start the server**
   ```bash
   # Development mode (with auto-restart)
   npm run dev

   # Production mode
   npm start
   ```

5. **Access the website**
   - Local: `http://localhost:3000`
   - Server health check: `http://localhost:3000/api/health`

## 📧 Google Apps Script Setup

### 1. Create a Google Apps Script

1. Go to [Google Apps Script](https://script.google.com/)
2. Create a new project
3. Replace the default code with the following:

```javascript
// Google Apps Script Code
function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);

    // Open Google Sheet (replace with your sheet ID)
    const sheetId = 'YOUR_GOOGLE_SHEET_ID';
    const sheet = SpreadsheetApp.openById(sheetId).getSheetByName('Contact_Form');

    // Add headers if sheet is empty
    if (sheet.getLastRow() === 0) {
      const headers = [
        'Timestamp', 'Full Name', 'First Name', 'Last Name', 'Email', 'Phone',
        'Interest', 'Subject', 'Message', 'Newsletter', 'Source', 'IP', 'User Agent'
      ];
      sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    }

    // Add new row
    const rowData = [
      data.timestamp,
      data.fullName,
      data.firstName,
      data.lastName,
      data.email,
      data.phone,
      data.interest,
      data.subject,
      data.message,
      data.newsletter,
      data.source,
      data.ip,
      data.userAgent
    ];

    sheet.appendRow(rowData);

    // Send confirmation email (optional)
    try {
      const subject = `New Contact Form Submission - ${data.interest}`;
      const body = `
        New contact form submission received:

        Name: ${data.fullName}
        Email: ${data.email}
        Phone: ${data.phone}
        Interest: ${data.interest}
        Subject: ${data.subject}

        Message:
        ${data.message}

        Newsletter: ${data.newsletter}
        Source: ${data.source}
        IP: ${data.ip}
      `;

      // Replace with your email
      MailApp.sendEmail('info@yuvabot.com', subject, body);
    } catch (emailError) {
      console.error('Email sending failed:', emailError);
    }

    return ContentService
      .createTextOutput(JSON.stringify({
        success: true,
        id: new Date().getTime().toString(),
        message: 'Form submitted successfully'
      }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (error) {
    console.error('Error processing form submission:', error);
    return ContentService
      .createTextOutput(JSON.stringify({
        success: false,
        error: error.message
      }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
```

### 2. Create a Google Sheet

1. Create a new Google Sheet
2. Name the first sheet "Contact_Form"
3. Copy the Sheet ID from the URL
4. Update the `sheetId` variable in your Apps Script

### 3. Deploy the Apps Script

1. Click "Deploy" > "New deployment"
2. Select type: "Web app"
3. Description: "Yuvabot Contact Form Handler"
4. Execute as: "Me"
5. Who has access: "Anyone"
6. Deploy and copy the web app URL

### 4. Update your `.env` file

```bash
APPS_SCRIPT_URL=https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/exec
```

## 📁 Project Structure

```
website/
├── server.js              # Express server
├── package.json           # Dependencies
├── home.html             # Main website
├── admin.html            # Admin dashboard
├── robots.txt            # Search engine crawling instructions
├── sitemap.xml           # XML sitemap for search engines
├── humans.txt            # Credits and site information
├── manifest.json         # PWA manifest for app installation
├── sw.js                 # Service worker for PWA
├── README.md             # This file
├── .env                  # Environment variables (create this)
├── .env.template         # Environment template
└── .gitignore            # Git ignore rules
```

## 🔧 API Endpoints

### Contact Form
```
POST /api/contact
```
Submits contact form data to Google Apps Script.

**Request Body:**
```json
{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "phone": "+91 9876543210",
  "interest": "Cyber Security",
  "subject": "Training Inquiry",
  "message": "I am interested in your cyber security training.",
  "newsletter": true
}
```

### Newsletter Subscription
```
POST /api/newsletter
```
Subscribes email to newsletter.

**Request Body:**
```json
{
  "email": "user@example.com"
}
```

### Career Registration
```
POST /api/career/student  # Student registration
POST /api/career/college  # College registration
```

### Health Check
```
GET /api/health
```
Returns server status and uptime.

### Admin Dashboard
```
GET /xyzadminsCybEr
```
Access admin dashboard (requires authentication).

**Default Credentials:**
- Username: `xyzadminsCybEr`
- Password: `admin@2024`

**Admin API Endpoints:**
```
GET /api/admin/stats     # Dashboard statistics
GET /api/admin/contacts  # Contact form submissions
GET /api/admin/newsletter # Newsletter subscribers
GET /api/admin/students  # Student registrations
GET /api/admin/colleges  # College registrations
```

All admin endpoints require Basic Authentication.

## 🛡️ Security Features

- **Helmet.js**: Security headers
- **Rate Limiting**: Prevents abuse
- **CORS**: Configurable cross-origin requests
- **Input Validation**: Server-side validation
- **Compression**: Gzip compression for faster loading

## 🔍 SEO & PWA Features

### Search Engine Optimization
- **robots.txt**: Guides search engine crawlers
- **sitemap.xml**: Helps search engines index all pages
- **Meta tags**: Open Graph, Twitter Cards, canonical URLs
- **Structured content**: Semantic HTML with proper headings
- **Mobile-first**: Responsive design for all devices

### Progressive Web App (PWA)
- **Web App Manifest**: Allows installation as a native app
- **Service Worker**: Basic offline caching for core resources
- **App Shortcuts**: Quick access to key sections
- **Theme Colors**: Matches your brand colors

### Files Included
- `robots.txt` - Search engine crawling instructions
- `sitemap.xml` - XML sitemap with all sections
- `humans.txt` - Credits and team information
- `manifest.json` - PWA configuration

## 🚀 Deployment

### For Production

1. Set `NODE_ENV=production` in your environment
2. Use a process manager like PM2:
   ```bash
   npm install -g pm2
   pm2 start server.js --name "yuvabot-website"
   ```

3. Set up a reverse proxy (nginx/apache) for better performance

### Environment Variables for Production

```bash
NODE_ENV=production
PORT=3000
ALLOWED_ORIGINS=https://yourdomain.com,https://www.yourdomain.com
APPS_SCRIPT_URL=https://script.google.com/macros/s/YOUR_PRODUCTION_SCRIPT_ID/exec
```

### Domain Configuration
When deploying to a domain, update these files:
- `sitemap.xml`: Change `https://yuvabot.com/` to your actual domain
- `robots.txt`: Update sitemap URL to match your domain
- Social media meta tags in `home.html`

## 🔒 Security Notes

### Admin Access
- **Default Admin URL:** `/xyzadminsCybEr`
- **Default Credentials:** `xyzadminsCybEr` / `admin@2024`
- **Change these immediately in production!**
- Set `ADMIN_USER` and `ADMIN_PASS` environment variables

### Production Security
- Use HTTPS in production
- Implement proper session management
- Add rate limiting for admin endpoints
- Use environment variables for all sensitive data
- Regularly update admin credentials

### Testing Admin Features
Run the admin test script to verify functionality:
```bash
npm run test-admin
```

This will test:
- Admin page accessibility
- API endpoints with authentication
- Authentication security

## 🔒 Security Features

### OWASP Top 10 Compliance

This website implements comprehensive security measures according to OWASP Top 10:

#### 1. **Broken Access Control** ✅
- HTTP Basic Authentication for admin routes
- Admin pages blocked from search engines
- Role-based access control implemented

#### 2. **Cryptographic Failures** ✅
- Secure session management with strong secrets
- HTTPS-only cookies in production
- Secure password hashing (bcrypt)

#### 3. **Injection** ✅
- Input validation with express-validator
- MongoDB sanitization (mongo-sanitize)
- XSS prevention (xss-clean)
- SQL injection prevention through parameterized queries

#### 4. **Insecure Design** ✅
- Rate limiting (express-rate-limit)
- Speed limiting (express-slow-down)
- HTTP Parameter Pollution protection (hpp)

#### 5. **Security Misconfiguration** ✅
- Helmet.js for comprehensive security headers
- Content Security Policy (CSP) configured
- CORS properly configured
- Secure session configuration

#### 6. **Vulnerable and Outdated Components** ✅
- Dependencies regularly audited
- Security updates monitored
- Automated dependency updates

#### 7. **Identification and Authentication Failures** ✅
- Secure session management
- CSRF protection (csurf)
- SameSite cookie attributes
- Secure password policies

#### 8. **Software and Data Integrity Failures** ✅
- Subresource Integrity (SRI) for external scripts
- PWA manifest with integrity checks
- Secure external API communications

#### 9. **Security Logging and Monitoring Failures** ✅
- Comprehensive security event logging
- Error monitoring and alerting
- Audit trails for sensitive operations
- Performance monitoring

#### 10. **Server-Side Request Forgery (SSRF)** ✅
- Whitelisted domains for external requests
- Request timeouts and abort controllers
- Input validation for URLs

### Security Monitoring

Run security audits regularly:

```bash
# Run comprehensive security audit
npm run security-audit

# Check security status
curl http://localhost:3000/api/security/status

# View security logs (when authenticated)
# Access admin dashboard for monitoring
```

### Security Configuration

Key security settings in `security-config.js`:
- Rate limiting configurations
- Session security settings
- CORS policies
- CSP directives
- Input validation rules

### Production Security Checklist

- [ ] Set strong `SESSION_SECRET` environment variable
- [ ] Enable HTTPS with valid SSL certificate
- [ ] Configure `ALLOWED_ORIGINS` for production domains
- [ ] Set up monitoring and alerting
- [ ] Regularly update dependencies
- [ ] Monitor security logs
- [ ] Implement backup and recovery procedures

## 📧 Google Apps Script Integration

### Complete Setup Guide

Follow the detailed deployment guide in `APPS_SCRIPT_DEPLOYMENT.md` for step-by-step instructions.

### Quick Setup

1. **Copy code from `code.gs`** and paste into Google Apps Script
2. **Deploy as web app** with "Execute as: Me" and "Who has access: Anyone"
3. **Update your `.env` file:**
   ```bash
   APPS_SCRIPT_URL=https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/exec
   ```

### Features

- **Dual Form Handling:** Contact forms and Business enquiries saved to separate Google Sheets
- **Email Notifications:** Sends confirmation emails to admin for both form types
- **Admin Dashboard Integration:** Real-time data fetching from both sheets
- **Error Handling:** Comprehensive logging and error responses
- **Security:** Input validation and sanitization for all forms

### Testing the Integration

```bash
# 1. Test Apps Script directly
npm run test-apps-script

# 2. Test contact form submission
curl -X POST http://localhost:3000/api/contact \
  -H "Content-Type: application/json" \
  -d '{
    "firstName":"Test",
    "lastName":"User",
    "email":"test@example.com",
    "message":"Test message from API"
  }'

# 3. Check admin dashboard
# Visit: http://localhost:3000/xyzadminsCybEr
# Login with admin credentials
```

### Google Sheet Structure

Your Google Sheet will automatically create these columns:
- Timestamp, Request ID
- Full Name, First Name, Last Name
- Email, Phone
- Interest, Subject, Message
- Newsletter, Source
- IP Address, User Agent, Status

### Admin Dashboard Features

- **Real-time Statistics:** Contact count, newsletter subscriptions
- **Contact Management:** View all form submissions
- **Data Export:** Direct access to Google Sheets
- **Email Integration:** Automatic admin notifications

### Troubleshooting

1. **"Script not found" error:**
   - Verify the deployment URL is correct
   - Check that Apps Script is deployed as web app

2. **Data not saving:**
   - Confirm Sheet ID is correct in Apps Script
   - Check Google Sheet permissions

3. **Admin dashboard shows mock data:**
   - Google Apps Script integration may not be complete
   - Check server logs for connection errors

### Advanced Configuration

- **Custom Email Templates:** Modify the email content in Apps Script
- **Additional Form Fields:** Update both frontend and Apps Script
- **Multiple Sheets:** Create separate sheets for different form types
- **Data Validation:** Add custom validation rules in Apps Script

### Troubleshooting

If Apps Script isn't working, see `APPS_SCRIPT_TROUBLESHOOTING.md` for detailed solutions.

**Quick debug:**
```bash
npm run debug-apps-script
```

**Common fixes:**
- Use `code-simple.gs` if `code.gs` fails
- Check Apps Script execution logs
- Verify sheet permissions and IDs
- Redeploy if URL has changed

## 📞 Support

For technical support or questions:
- Email: info@yuvabot.com
- Phone: +91 98765 43210

## 📄 License

MIT License - see LICENSE file for details.

---

**Yuvabot Lab Private Limited** © 2024. Empowering innovation through technology and education.

