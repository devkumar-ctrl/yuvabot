# 🚀 Google Apps Script Deployment Guide

## Step-by-Step Setup

### 1. Create Google Apps Script Project

1. Go to [Google Apps Script](https://script.google.com)
2. Click **"New Project"**
3. Name it: `Yuvabot Lab Form Handler`
4. Delete the default code

### 2. Copy the Code

1. Open the `code.gs` file from this project
2. Copy all the code
3. Paste it into the Google Apps Script editor
4. Click **"Save"** (Ctrl+S)

### 3. Deploy as Web App

1. Click **"Deploy"** → **"New deployment"**
2. Select **"Web app"** as the type
3. Configure settings:
   - **Description**: `Yuvabot Lab Contact & Enquiry Form Handler`
   - **Execute as**: `Me`
   - **Who has access**: `Anyone` (important!)
4. Click **"Deploy"**
5. **Copy the Web App URL** - it looks like:
   ```
   https://script.google.com/macros/s/DEPLOYMENT_ID/exec
   ```

### 4. Update Your Website Configuration

1. Open your `.env` file (or create one)
2. Add this line:
   ```bash
   APPS_SCRIPT_URL=https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/exec
   ```
3. Replace `YOUR_DEPLOYMENT_ID` with your actual deployment ID

### 5. Test the Integration

```bash
# Start your server
npm start

# Test contact form
curl -X POST http://localhost:3000/api/contact \
  -H "Content-Type: application/json" \
  -d '{"firstName":"Test","lastName":"User","email":"test@example.com","message":"Test"}'

# Test enquiry form
curl -X POST http://localhost:3000/api/enquiry \
  -H "Content-Type: application/json" \
  -d '{"name":"Test Company","email":"test@company.com","message":"Test enquiry"}'

# Check admin dashboard
# Visit: http://localhost:3000/xyzadminsCybEr
# Login: xyzadminsCybEr / admin@2024
```

## 📊 Google Sheets Setup

### Contact Form Sheet
- **URL**: https://docs.google.com/spreadsheets/d/14YjIkCiVp2kRYK1i2rR-YxHy662KuSjPjZs-EQQUTVY/edit
- **Sheet Name**: `Contact_Form` (auto-created)

### Enquiry Form Sheet
- **URL**: https://docs.google.com/spreadsheets/d/1BtWoJ5ucDkJxa0MFSN8MzzRc8-1T2YZRM0qfFkysX80/edit
- **Sheet Name**: `Enquiries` (auto-created)

## 🔧 Configuration

The script is pre-configured with:
- **Contact Sheet ID**: `14YjIkCiVp2kRYK1i2rR-YxHy662KuSjPjZs-EQQUTVY`
- **Enquiry Sheet ID**: `1BtWoJ5ucDkJxa0MFSN8MzzRc8-1T2YZRM0qfFkysX80`
- **Admin Email**: `info@yuvabot.com`

## 🧪 Testing Functions

In Google Apps Script editor, you can test the functions:

```javascript
// Test contact form
testContactForm();

// Test enquiry form
testEnquiryForm();
```

Run these in the editor and check the logs and your Google Sheets.

## 📧 Email Notifications

The script automatically sends email notifications to `info@yuvabot.com` for:
- New contact form submissions
- New business enquiries

## 🔒 Security Features

- Input validation and sanitization
- Request rate limiting (via your website)
- Secure data handling
- Error logging

## 🐛 Troubleshooting

### Common Issues:

1. **"Script not found" error**
   - Check the deployment URL is correct
   - Ensure the script is deployed as web app

2. **Data not saving**
   - Verify Sheet IDs are correct in the CONFIG
   - Check Google Sheet permissions
   - Look at Apps Script execution logs

3. **Emails not sending**
   - Verify admin email is set correctly
   - Check Apps Script email permissions

### Debug Steps:

1. Check Apps Script **View → Logs**
2. Test with the provided test functions
3. Verify sheet permissions and sharing settings
4. Check your website's server logs

## 📞 Support

If you encounter issues:
1. Check the Apps Script execution logs
2. Verify all sheet IDs are correct
3. Test with the provided curl commands
4. Ensure proper permissions are granted

---

**Your Google Apps Script is now ready for deployment!** 🎉

Copy the code from `code.gs` and follow the steps above.
