# 🔧 Google Apps Script Troubleshooting Guide

## Common Issues & Solutions

### ❌ Issue: "Script not found" or "Invalid script" error

**Symptoms:**
- HTTP 404 or 500 errors when submitting forms
- Apps Script URL not working

**Solutions:**
1. **Check deployment URL:**
   - Ensure you're using the correct deployment URL
   - Should end with `/exec`, not `/dev` or `/edit`

2. **Redeploy the script:**
   - Go to Apps Script editor
   - Click "Deploy" → "Manage deployments"
   - Create new deployment or update existing one
   - Copy the new URL

3. **Check script permissions:**
   - Ensure "Who has access" is set to "Anyone"
   - "Execute as" should be "Me"

### ❌ Issue: Data not saving to Google Sheets

**Symptoms:**
- Form submission succeeds but no data appears in sheets
- Apps Script logs show success but sheets are empty

**Solutions:**
1. **Verify Sheet IDs:**
   ```javascript
   // In your code.gs, check these IDs match your sheets:
   CONTACT_SHEET_ID: '14YjIkCiVp2kRYK1i2rR-YxHy662KuSjPjZs-EQQUTVY'
   ENQUIRY_SHEET_ID: '1BtWoJ5ucDkJxa0MFSN8MzzRc8-1T2YZRM0qfFkysX80'
   ```

2. **Check sheet permissions:**
   - Ensure Apps Script has edit access to your sheets
   - Share sheets with the Apps Script service account

3. **Verify sheet names:**
   - Contact forms use: `Contact_Form` sheet
   - Enquiries use: `Enquiries` sheet
   - Sheets are auto-created if they don't exist

### ❌ Issue: Email notifications not working

**Symptoms:**
- Form submissions work but no emails received

**Solutions:**
1. **Check email address:**
   ```javascript
   ADMIN_EMAIL: 'info@yuvabot.com'  // Ensure this is correct
   ```

2. **Verify Apps Script email permissions:**
   - First run may require email authorization
   - Check Apps Script execution logs for email errors

3. **Check spam folder:**
   - Emails might be going to spam
   - Add `info@yuvabot.com` to safe senders

### ❌ Issue: CORS errors

**Symptoms:**
- Browser console shows CORS errors
- Form submissions fail with network errors

**Solutions:**
1. **Check your server CORS configuration:**
   ```javascript
   // In server.js, ensure script.google.com is allowed
   cors: {
     origin: ['http://localhost:3000', 'https://script.google.com']
   }
   ```

2. **Verify Apps Script deployment:**
   - Ensure script is deployed as web app
   - Check that "Who has access" is "Anyone"

### ❌ Issue: Authentication errors for admin endpoints

**Symptoms:**
- Admin dashboard shows authentication errors
- Cannot access `/api/admin/*` endpoints

**Solutions:**
1. **Check admin credentials in server.js:**
   ```javascript
   const ADMIN_USER = process.env.ADMIN_USER || 'xyzadminsCybEr';
   const ADMIN_PASS = process.env.ADMIN_PASS || 'admin@2024';
   ```

2. **Verify Basic Auth header:**
   - Apps Script expects: `Authorization: Basic <base64-encoded-credentials>`

## 🔍 Debug Steps

### 1. Test Apps Script Directly

Run the debug script:
```bash
npm run debug-apps-script
```

This will test:
- Basic connectivity
- Contact form submission
- Enquiry form submission
- Admin stats endpoint

### 2. Check Apps Script Logs

1. Go to [Google Apps Script](https://script.google.com)
2. Open your project
3. Click "Executions" in the left menu
4. Check recent executions for errors
5. Click on failed executions to see detailed logs

### 3. Test Functions Manually

In Apps Script editor:
```javascript
// Run these functions to test
testContactForm();
testEnquiryForm();
```

Check the logs after running.

### 4. Verify Sheet Access

1. Share your Google Sheets with the Apps Script:
   - Open each sheet
   - Click "Share"
   - Add: `script-editor-access@google.com`

## 🛠️ Alternative: Use Simple Version

If the main version doesn't work, try `code-simple.gs`:

1. Copy contents of `code-simple.gs`
2. Paste into new Apps Script project
3. Deploy as web app
4. Update your `.env` file with new URL

The simple version uses older JavaScript syntax that's more compatible with Apps Script.

## 📊 Verify Data Flow

### Contact Form Data Flow:
```
Website Form → Server (/api/contact) → Google Apps Script → Contact Sheet
```

### Enquiry Form Data Flow:
```
Website Form → Server (/api/enquiry) → Google Apps Script → Enquiry Sheet
```

### Email Flow:
```
Form Submission → Google Apps Script → MailApp.sendEmail() → info@yuvabot.com
```

## 🔧 Quick Fix Commands

```bash
# Test basic connectivity
curl -X POST https://script.google.com/macros/s/YOUR_ID/exec \
  -H "Content-Type: application/json" \
  -d '{"test": "connection"}'

# Test contact form
npm run test-contact

# Test enquiry form
npm run test-enquiry

# Debug full integration
npm run debug-apps-script
```

## 🚨 Emergency Solutions

### If nothing works:

1. **Create new Apps Script project**
2. **Use `code-simple.gs` instead of `code.gs`**
3. **Create new Google Sheets** and update IDs
4. **Redeploy everything**
5. **Update all URLs in your `.env` file**

### Minimal working version:
```javascript
// Minimal Apps Script
function doPost(e) {
  var data = JSON.parse(e.postData.contents);
  Logger.log('Received: ' + JSON.stringify(data));

  return ContentService
    .createTextOutput(JSON.stringify({success: true}))
    .setMimeType(ContentService.MimeType.JSON);
}
```

## 📞 Need Help?

1. Check the **Apps Script execution logs** first
2. Run the **debug script**: `npm run debug-apps-script`
3. Verify **sheet permissions** and **IDs**
4. Test with **simple version** if complex version fails
5. Check **email permissions** and **spam folders**

## ✅ Success Checklist

- [ ] Apps Script deployed successfully
- [ ] Web app URL works (returns JSON response)
- [ ] Sheet IDs are correct
- [ ] Sheets are shared with Apps Script
- [ ] Email permissions granted
- [ ] Server `.env` file updated
- [ ] Form submissions work from website
- [ ] Data appears in Google Sheets
- [ ] Email notifications received

**Debug output will help identify exactly where the issue occurs!** 🔍
