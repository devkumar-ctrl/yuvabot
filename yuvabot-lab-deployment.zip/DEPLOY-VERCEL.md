# 🚀 Deploy Yuvabot Lab Website to Vercel

## Prerequisites

- ✅ Vercel account (free at [vercel.com](https://vercel.com))
- ✅ GitHub account
- ✅ Google Apps Script deployed (optional but recommended)
- ✅ Domain name (optional)

## Step 1: Prepare Your Code

### 1.1 Install Vercel CLI
```bash
npm install -g vercel
vercel login
```

### 1.2 Test Locally First
```bash
# Make sure everything works locally
npm start
# Visit http://localhost:3000
```

### 1.3 Update Environment Variables

Your website needs these environment variables:

#### Required Variables:
- `APPS_SCRIPT_URL` - Your Google Apps Script deployment URL
- `ADMIN_USER` - Admin dashboard username
- `ADMIN_PASS` - Admin dashboard password

#### Optional Variables:
- `NODE_ENV` - Set to 'production'
- `SESSION_SECRET` - Random string for session security

## Step 2: Deploy to Vercel

### Method 1: Vercel CLI (Recommended)

```bash
cd /path/to/your/website

# Initialize Vercel project
vercel

# Answer the prompts:
# - Link to existing project or create new? → Create new
# - Project name → yuvabot-lab (or your choice)
# - Directory → ./ (current directory)

# Deploy
vercel --prod
```

### Method 2: GitHub Integration

1. **Push to GitHub:**
```bash
git init
git add .
git commit -m "Initial commit - Yuvabot Lab Website"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/yuvabot-lab.git
git push -u origin main
```

2. **Connect to Vercel:**
   - Go to [vercel.com](https://vercel.com)
   - Click "New Project"
   - Import your GitHub repository
   - Vercel will auto-detect the settings from `vercel.json`

## Step 3: Configure Environment Variables

### Via Vercel Dashboard:
1. Go to your project in Vercel dashboard
2. Click "Settings" → "Environment Variables"
3. Add these variables:

```
APPS_SCRIPT_URL=https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/exec
ADMIN_USER=xyzadminsCybEr
ADMIN_PASS=your-secure-admin-password-here
NODE_ENV=production
SESSION_SECRET=your-random-secure-string-here
```

### Via CLI:
```bash
vercel env add APPS_SCRIPT_URL
vercel env add ADMIN_USER
vercel env add ADMIN_PASS
vercel env add NODE_ENV
vercel env add SESSION_SECRET
```

## Step 4: Custom Domain (Optional)

### Add Custom Domain:
```bash
# Via CLI
vercel domains add yourdomain.com

# Or via Dashboard:
# Settings → Domains → Add yourdomain.com
```

### DNS Configuration:
Vercel will provide DNS records. Add them to your domain registrar:

```
Type: CNAME
Name: www (or @ for root)
Value: cname.vercel-dns.com
```

## Step 5: Test Your Deployment

### Basic Tests:
```bash
# Get your deployment URL from Vercel
DEPLOYMENT_URL=https://your-project.vercel.app

# Test homepage
curl $DEPLOYMENT_URL

# Test forms (if Apps Script configured)
curl -X POST $DEPLOYMENT_URL/api/contact \
  -H "Content-Type: application/json" \
  -d '{"firstName":"Test","lastName":"User","email":"test@example.com","message":"Test from Vercel"}'
```

### Admin Dashboard:
- Visit: `https://your-project.vercel.app/xyzadminsCybEr`
- Login with your configured admin credentials

## Troubleshooting

### Common Issues:

#### 1. Build Failures:
```bash
# Check Vercel logs
vercel logs

# Common fixes:
# - Check package.json scripts
# - Ensure all dependencies are listed
# - Verify Node.js version compatibility
```

#### 2. Environment Variables Not Working:
```bash
# Redeploy after adding env vars
vercel --prod

# Or trigger new deployment in dashboard
```

#### 3. Apps Script CORS Issues:
```bash
# Ensure Apps Script allows CORS from your Vercel domain
# Add your Vercel domain to Apps Script CORS settings
```

#### 4. Static Files Not Loading:
```bash
# Check vercel.json routes
# Ensure static files are in correct directory
```

### Performance Optimization:

#### 1. Enable Vercel Analytics:
```bash
# In Vercel dashboard: Settings → Analytics → Enable
```

#### 2. Custom Domain with CDN:
- Vercel automatically provides CDN
- Custom domains get free SSL certificates

#### 3. Function Optimization:
- Functions auto-scale
- Cold starts are minimal for Node.js apps

## Security Checklist

- [x] HTTPS enabled automatically
- [x] Security headers configured in `vercel.json`
- [x] Rate limiting active
- [x] Input validation enabled
- [x] Admin authentication secure
- [x] Environment variables protected

## Monitoring & Maintenance

### Vercel Dashboard Features:
- **Real-time Logs:** View function logs
- **Analytics:** Traffic and performance metrics
- **Functions:** Monitor serverless function usage
- **Domains:** SSL certificate management

### Regular Tasks:
```bash
# Update dependencies monthly
npm update
npm audit fix

# Deploy updates
git add .
git commit -m "Security updates"
git push

# Vercel auto-deploys from main branch
```

## Cost Estimation

### Vercel Free Tier:
- ✅ 100GB bandwidth/month
- ✅ 100 serverless function invocations/day
- ✅ Custom domain support
- ✅ Automatic HTTPS

### Potential Costs:
- Additional bandwidth: $0.15/GB
- Additional functions: $0.20/1k invocations
- Pro features: $20/month (analytics, etc.)

## Backup & Recovery

### Code Backup:
- All code is in GitHub
- Vercel maintains deployment history

### Data Backup:
- Form submissions stored in Google Sheets
- Admin credentials in environment variables

## Success Metrics

After deployment, monitor:
- ✅ Website loads successfully
- ✅ Forms submit without errors
- ✅ Admin dashboard accessible
- ✅ SEO files accessible (robots.txt, sitemap.xml)
- ✅ PWA manifest working
- ✅ Mobile responsiveness

---

## 🎉 Deployment Complete!

Your **Yuvabot Lab website** is now live on Vercel!

**Access your site:** `https://your-project.vercel.app`

**Admin Dashboard:** `https://your-project.vercel.app/xyzadminsCybEr`

**Need help?** Check the troubleshooting section above or Vercel documentation.
