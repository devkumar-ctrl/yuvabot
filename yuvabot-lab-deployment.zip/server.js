const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const slowDown = require('express-slow-down');
const mongoSanitize = require('express-mongo-sanitize');
const hpp = require('hpp');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const path = require('path');
const crypto = require('crypto');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// ==================== SECURITY MIDDLEWARE ====================

// Trust proxy for accurate IP detection behind load balancers
app.set('trust proxy', 1);

// Comprehensive security headers with Helmet
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://cdn.tailwindcss.com", "https://cdnjs.cloudflare.com", "https://fonts.googleapis.com"],
      scriptSrc: ["'self'", "'unsafe-inline'", "https://cdn.tailwindcss.com", "https://cdnjs.cloudflare.com", "https://threejs.org"],
      imgSrc: ["'self'", "data:", "https:", "blob:"],
      connectSrc: ["'self'", "https://script.google.com", "https://maps.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com", "https://cdnjs.cloudflare.com"],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'"],
      frameSrc: ["'none'"],
      upgradeInsecureRequests: process.env.NODE_ENV === 'production' ? [] : null,
    },
  },
  crossOriginEmbedderPolicy: false,
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true
  }
}));

// Rate limiting - General API rate limit
const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: {
    success: false,
    error: 'Too many requests from this IP, please try again later.',
    retryAfter: '15 minutes'
  },
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.path.startsWith('/static') || req.path === '/robots.txt' || req.path === '/sitemap.xml'
});

// Stricter rate limiting for auth endpoints
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // limit each IP to 5 auth attempts per windowMs
  message: {
    success: false,
    error: 'Too many authentication attempts, please try again later.',
    retryAfter: '15 minutes'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Speed limiting to prevent brute force
const speedLimiter = slowDown({
  windowMs: 15 * 60 * 1000, // 15 minutes
  delayAfter: 10, // allow 10 requests per windowMs without delay
  delayMs: 500, // add 500ms of delay per request after delayAfter
});

// Data sanitization against NoSQL injection
app.use(mongoSanitize({
  replaceWith: '_'
}));

// XSS protection is handled by Helmet CSP and input validation

// Prevent parameter pollution
app.use(hpp({
  whitelist: ['sort', 'fields', 'page', 'limit'] // Allow certain parameters to be duplicated
}));

// ==================== SESSION MANAGEMENT ====================

// Session configuration with security
app.use(session({
  name: 'yuvabot.sid', // Don't use default session name
  secret: process.env.SESSION_SECRET || 'fallback-secret-change-in-production-' + crypto.randomBytes(32).toString('hex'),
  resave: false,
  saveUninitialized: false,
  store: process.env.MONGODB_URI ? MongoStore.create({
    mongoUrl: process.env.MONGODB_URI,
    ttl: 24 * 60 * 60 // 24 hours
  }) : undefined,
  cookie: {
    secure: process.env.NODE_ENV === 'production', // HTTPS only in production
    httpOnly: true, // Prevent XSS attacks
    maxAge: 24 * 60 * 60 * 1000, // 24 hours
    sameSite: 'strict' // CSRF protection
  }
}));

// CSRF Protection for forms (excluding GET requests and API)
const csrf = require('csurf');
const csrfProtection = csrf({
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    sameSite: 'strict'
  }
});

// Apply CSRF to form POST requests (but not API endpoints)
app.use((req, res, next) => {
  if (req.method === 'POST' && !req.path.startsWith('/api/')) {
    return csrfProtection(req, res, next);
  }
  next();
});

// Make CSRF token available to templates
app.use((req, res, next) => {
  if (req.csrfToken) {
    res.locals.csrfToken = req.csrfToken();
  }
  next();
});

// Apply rate limiting
app.use('/api/', generalLimiter);
app.use('/api/contact', speedLimiter);
app.use('/api/newsletter', speedLimiter);
app.use('/api/career', speedLimiter);
app.use('/xyzadminsCybEr', authLimiter);

// Compression middleware
app.use(compression());

// CORS middleware
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS ? process.env.ALLOWED_ORIGINS.split(',') : ['http://localhost:3000', 'http://127.0.0.1:3000'],
  credentials: true
}));

// Body parsing middleware with size limits
app.use(express.json({
  limit: '10mb',
  verify: (req, res, buf) => {
    // Verify content type for API endpoints
    if (req.originalUrl.startsWith('/api/') && req.get('content-type') !== 'application/json') {
      throw new Error('Content-Type must be application/json');
    }
  }
}));
app.use(express.urlencoded({
  extended: true,
  limit: '10mb'
}));

// ==================== INPUT VALIDATION & SANITIZATION ====================

const { body, validationResult } = require('express-validator');

// Input validation middleware
const validateContactForm = [
  body('firstName')
    .trim()
    .isLength({ min: 2, max: 50 })
    .withMessage('First name must be between 2 and 50 characters')
    .matches(/^[a-zA-Z\s]+$/)
    .withMessage('First name can only contain letters and spaces'),

  body('lastName')
    .trim()
    .isLength({ min: 2, max: 50 })
    .withMessage('Last name must be between 2 and 50 characters')
    .matches(/^[a-zA-Z\s]+$/)
    .withMessage('Last name can only contain letters and spaces'),

  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),

  body('phone')
    .optional()
    .matches(/^[\+]?[1-9][\d]{0,15}$/)
    .withMessage('Please provide a valid phone number'),

  body('interest')
    .optional()
    .isIn(['Cyber Security', 'IoT Training', 'STEM Education', 'Industrial Automation', 'Skill Training', 'Career Services', 'Custom Training', 'Consultation', 'Partnership Opportunities'])
    .withMessage('Please select a valid interest'),

  body('subject')
    .optional()
    .trim()
    .isLength({ max: 200 })
    .withMessage('Subject cannot exceed 200 characters'),

  body('message')
    .trim()
    .isLength({ min: 10, max: 2000 })
    .withMessage('Message must be between 10 and 2000 characters'),

  body('newsletter')
    .optional()
    .isBoolean()
    .withMessage('Newsletter preference must be true or false')
];

const validateNewsletter = [
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address')
];

const validateStudentRegistration = [
  body('name')
    .trim()
    .isLength({ min: 2, max: 100 })
    .withMessage('Name must be between 2 and 100 characters')
    .matches(/^[a-zA-Z\s]+$/)
    .withMessage('Name can only contain letters and spaces'),

  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),

  body('phone')
    .matches(/^[\+]?[1-9][\d]{0,15}$/)
    .withMessage('Please provide a valid phone number'),

  body('qualification')
    .isIn(['B.Tech/BE', 'Diploma', 'BCA/MCA', 'B.Sc/M.Sc', 'Other'])
    .withMessage('Please select a valid qualification'),

  body('branch')
    .optional()
    .trim()
    .isLength({ max: 100 })
    .withMessage('Branch cannot exceed 100 characters')
];

const validateCollegeRegistration = [
  body('collegeName')
    .trim()
    .isLength({ min: 3, max: 200 })
    .withMessage('College name must be between 3 and 200 characters'),

  body('contactPerson')
    .trim()
    .isLength({ min: 2, max: 100 })
    .withMessage('Contact person name must be between 2 and 100 characters')
    .matches(/^[a-zA-Z\s]+$/)
    .withMessage('Contact person name can only contain letters and spaces'),

  body('designation')
    .trim()
    .isLength({ min: 2, max: 100 })
    .withMessage('Designation must be between 2 and 100 characters'),

  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),

  body('phone')
    .matches(/^[\+]?[1-9][\d]{0,15}$/)
    .withMessage('Please provide a valid phone number'),

  body('driveType')
    .isIn(['Internship Only', 'Job Placement Only', 'Both Internship & Job'])
    .withMessage('Please select a valid drive type'),

  body('studentCount')
    .isInt({ min: 1, max: 10000 })
    .withMessage('Student count must be between 1 and 10000')
];

const validateEnquiry = [
  body('name')
    .trim()
    .isLength({ min: 2, max: 100 })
    .withMessage('Name must be between 2 and 100 characters')
    .matches(/^[a-zA-Z\s]+$/)
    .withMessage('Name can only contain letters and spaces'),

  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),

  body('phone')
    .optional()
    .matches(/^[\+]?[1-9][\d]{0,15}$/)
    .withMessage('Please provide a valid phone number'),

  body('company')
    .optional()
    .trim()
    .isLength({ max: 200 })
    .withMessage('Company name cannot exceed 200 characters'),

  body('serviceInterest')
    .optional()
    .isIn(['IoT Solutions', 'AI & Machine Learning', 'Cyber Security', 'Industrial Automation', 'STEM Education', 'Custom Development', 'Consultation', 'Other'])
    .withMessage('Please select a valid service interest'),

  body('budgetRange')
    .optional()
    .isIn(['Under ₹50,000', '₹50,000 - ₹2,00,000', '₹2,00,000 - ₹5,00,000', '₹5,00,000 - ₹10,00,000', 'Above ₹10,00,000', 'Not specified'])
    .withMessage('Please select a valid budget range'),

  body('timeline')
    .optional()
    .isIn(['ASAP', '1-3 months', '3-6 months', '6-12 months', 'Flexible'])
    .withMessage('Please select a valid timeline'),

  body('message')
    .trim()
    .isLength({ min: 10, max: 2000 })
    .withMessage('Message must be between 10 and 2000 characters')
];

// Validation error handler
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      error: 'Validation failed',
      details: errors.array().map(err => ({
        field: err.path,
        message: err.msg
      }))
    });
  }
  next();
};

// Serve static files from current directory
app.use(express.static(path.join(__dirname), {
  maxAge: '1d', // Cache static assets for 1 day
  etag: true
}));

// Serve homepage
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'home.html'));
});

// ==================== SECURITY MONITORING ENDPOINTS ====================

// Health check with security info
app.get('/api/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV || 'development',
    security: {
      rateLimiting: 'active',
      cors: 'configured',
      helmet: 'active',
      sanitization: 'active',
      validation: 'active'
    }
  });
});

// Security status endpoint (for monitoring)
app.get('/api/security/status', requireAuth, (req, res) => {
  res.json({
    timestamp: new Date().toISOString(),
    security: {
      status: 'SECURE',
      owaspCompliance: {
        brokenAccessControl: 'IMPLEMENTED',
        injection: 'PROTECTED',
        cryptoFailures: 'MITIGATED',
        insecureDesign: 'SECURE_BY_DESIGN',
        misconfiguration: 'SECURE_CONFIG',
        vulnerableComponents: 'MONITORED',
        authFailures: 'SECURE_AUTH',
        integrityFailures: 'PROTECTED',
        logging: 'COMPREHENSIVE',
        ssrf: 'PROTECTED'
      },
      middleware: {
        helmet: 'active',
        rateLimit: 'active',
        cors: 'active',
        sanitization: 'active',
        validation: 'active',
        csrf: 'active',
        session: 'secure'
      }
    }
  });
});

// ==================== SECURE API ENDPOINTS ====================

// Contact form submission endpoint (forwards to Google Apps Script)
app.post('/api/contact', validateContactForm, handleValidationErrors, async (req, res) => {
  try {
    const { firstName, lastName, email, phone, interest, subject, message, newsletter } = req.body;

    // Prepare data for Google Apps Script with security validation
    const formData = {
      timestamp: new Date().toISOString(),
      requestId: crypto.randomUUID(), // Unique request ID for tracking
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      fullName: `${firstName.trim()} ${lastName.trim()}`,
      email: email.toLowerCase().trim(),
      phone: phone ? phone.trim() : '',
      interest: interest || 'General Inquiry',
      subject: subject ? subject.trim() : '',
      message: message.trim(),
      newsletter: newsletter ? 'Yes' : 'No',
      source: 'Website Contact Form',
      ip: req.ip,
      userAgent: req.get('User-Agent'),
      security: {
        sanitized: true,
        validated: true,
        rateLimited: true
      }
    };

    // Additional security checks
    const suspiciousPatterns = [
      /<script/i,
      /javascript:/i,
      /on\w+\s*=/i,
      /eval\(/i,
      /document\./i,
      /window\./i,
      /location\./i
    ];

    const dataString = JSON.stringify(formData);
    for (const pattern of suspiciousPatterns) {
      if (pattern.test(dataString)) {
        logSecurityEvent('MALICIOUS_INPUT_DETECTED', {
          pattern: pattern.toString(),
          data: dataString.substring(0, 200) + '...',
          ip: req.ip
        });
        return res.status(400).json({
          success: false,
          error: 'Invalid input detected'
        });
      }
    }

    // Check if Apps Script URL is configured
    const appsScriptUrl = process.env.APPS_SCRIPT_URL;
    if (!appsScriptUrl) {
      console.error('APPS_SCRIPT_URL environment variable not set');
      return res.status(500).json({
        success: false,
        error: 'Server configuration error'
      });
    }

    // Forward to Google Apps Script with timeout and security
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout

    try {
      const response = await fetch(appsScriptUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'Yuvabot-Website/1.0',
          'X-Request-ID': formData.requestId
        },
        body: JSON.stringify(formData),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        logSecurityEvent('APPS_SCRIPT_ERROR', {
          status: response.status,
          statusText: response.statusText,
          url: appsScriptUrl,
          requestId: formData.requestId
        });
        throw new Error(`Apps Script responded with status: ${response.status}`);
      }

      const result = await response.json();

      // Log successful submission
      console.log(`✅ Contact form submitted successfully - Request ID: ${formData.requestId}`);

      res.json({
        success: true,
        message: 'Thank you for your message! We will get back to you soon.',
        data: {
          id: result.id || formData.requestId,
          timestamp: formData.timestamp
        }
      });

    } catch (fetchError) {
      clearTimeout(timeoutId);

      if (fetchError.name === 'AbortError') {
        logSecurityEvent('APPS_SCRIPT_TIMEOUT', {
          requestId: formData.requestId,
          timeout: '30s'
        });
        throw new Error('Request timeout - please try again later');
      }

      throw fetchError;
    }

    // Log successful submission
    console.log(`Contact form submitted by ${formData.fullName} (${formData.email})`);

    res.json({
      success: true,
      message: 'Thank you for your message! We will get back to you soon.',
      data: {
        id: result.id || Date.now().toString(),
        timestamp: formData.timestamp
      }
    });

  } catch (error) {
    console.error('Contact form submission error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to process your request. Please try again later.'
    });
  }
});

// Newsletter subscription endpoint
app.post('/api/newsletter', validateNewsletter, handleValidationErrors, async (req, res) => {
  try {
    const { email } = req.body;

    // Here you can integrate with your email service (Mailchimp, etc.)
    // For now, we'll just log it
    console.log(`Newsletter subscription: ${email}`);

    res.json({
      success: true,
      message: 'Thank you for subscribing to our newsletter!'
    });

  } catch (error) {
    console.error('Newsletter subscription error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to process subscription. Please try again later.'
    });
  }
});

// Enquiry form endpoint
app.post('/api/enquiry', validateEnquiry, handleValidationErrors, async (req, res) => {
  try {
    const enquiryData = req.body;

    // Add form type identifier
    enquiryData.formType = 'enquiry';

    // Forward to Google Apps Script
    const appsScriptUrl = process.env.APPS_SCRIPT_URL;
    if (!appsScriptUrl) {
      return res.status(500).json({
        success: false,
        error: 'Server configuration error'
      });
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000);

    try {
      const response = await fetch(appsScriptUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'Yuvabot-Website/1.0',
          'X-Request-ID': enquiryData.requestId
        },
        body: JSON.stringify(enquiryData),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        logSecurityEvent('ENQUIRY_SUBMISSION_ERROR', {
          status: response.status,
          statusText: response.statusText,
          url: appsScriptUrl,
          requestId: enquiryData.requestId
        });
        throw new Error(`Apps Script responded with status: ${response.status}`);
      }

      const result = await response.json();

      console.log(`✅ Enquiry submitted successfully - Request ID: ${enquiryData.requestId}`);

      res.json({
        success: true,
        message: 'Thank you for your enquiry! We will get back to you soon.',
        data: {
          id: result.id || enquiryData.requestId,
          timestamp: enquiryData.timestamp
        }
      });

    } catch (fetchError) {
      clearTimeout(timeoutId);
      throw fetchError;
    }

  } catch (error) {
    console.error('Enquiry submission error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to process your enquiry. Please try again later.'
    });
  }
});

// Career registration endpoints
app.post('/api/career/student', validateStudentRegistration, handleValidationErrors, async (req, res) => {
  try {
    const studentData = req.body;

    res.json({
      success: true,
      message: 'Registration successful! We will contact you soon.'
    });

  } catch (error) {
    console.error('Student registration error:', error);
    res.status(500).json({
      success: false,
      error: 'Registration failed. Please try again later.'
    });
  }
});

app.post('/api/career/college', validateCollegeRegistration, handleValidationErrors, async (req, res) => {
  try {
    const collegeData = req.body;

    res.json({
      success: true,
      message: 'Registration successful! Our team will contact you within 24 hours.'
    });

  } catch (error) {
    console.error('College registration error:', error);
    res.status(500).json({
      success: false,
      error: 'Registration failed. Please try again later.'
    });
  }
});

// Basic authentication middleware for admin routes
function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Basic ')) {
    res.setHeader('WWW-Authenticate', 'Basic realm="Admin Area"');
    return res.status(401).json({ error: 'Authentication required' });
  }

  const base64Credentials = authHeader.split(' ')[1];
  const credentials = Buffer.from(base64Credentials, 'base64').toString('ascii');
  const [username, password] = credentials.split(':');

  // Simple authentication (in production, use proper auth)
  const ADMIN_USER = process.env.ADMIN_USER || 'xyzadminsCybEr';
  const ADMIN_PASS = process.env.ADMIN_PASS || 'admin@2024';

  if (username === ADMIN_USER && password === ADMIN_PASS) {
    req.user = { username };
    next();
  } else {
    res.status(401).json({ error: 'Invalid credentials' });
  }
}

// Serve admin page with authentication
app.get('/xyzadminsCybEr', (req, res) => {
  res.sendFile(path.join(__dirname, 'admin.html'));
});

// Admin API routes
app.get('/api/admin/stats', requireAuth, async (req, res) => {
  try {
    // Try to fetch real stats from Google Sheets
    const appsScriptUrl = process.env.APPS_SCRIPT_URL;

    if (appsScriptUrl) {
      try {
        // Create a special endpoint for stats in Google Apps Script
        const statsUrl = appsScriptUrl.replace('/exec', '/exec?action=getStats');

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout

        const response = await fetch(statsUrl, {
          method: 'GET',
          headers: {
            'User-Agent': 'Yuvabot-Admin/1.0',
          },
          signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (response.ok) {
          const stats = await response.json();
          return res.json(stats);
        }
      } catch (fetchError) {
        console.log('Could not fetch real stats, using mock data:', fetchError.message);
      }
    }

    // Fallback to mock data if Google Sheets integration fails
    const mockStats = {
      contacts: Math.floor(Math.random() * 20) + 10,
      newsletter: Math.floor(Math.random() * 15) + 5,
      students: Math.floor(Math.random() * 10) + 5,
      colleges: Math.floor(Math.random() * 5) + 1,
      lastUpdated: new Date().toISOString()
    };

    res.json(mockStats);
  } catch (error) {
    console.error('Error fetching admin stats:', error);
    res.status(500).json({ error: 'Failed to fetch statistics' });
  }
});

app.get('/api/admin/contacts', requireAuth, async (req, res) => {
  try {
    // Try to fetch real data from Google Sheets
    const appsScriptUrl = process.env.APPS_SCRIPT_URL;

    if (appsScriptUrl) {
      try {
        // Create endpoint for fetching contacts
        const contactsUrl = appsScriptUrl.replace('/exec', '/exec?action=getContacts');

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 15000); // 15 second timeout

        const response = await fetch(contactsUrl, {
          method: 'GET',
          headers: {
            'User-Agent': 'Yuvabot-Admin/1.0',
            'Authorization': req.headers.authorization
          },
          signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (response.ok) {
          const data = await response.json();
          if (data.success && data.data) {
            return res.json(data.data.slice(-20)); // Return last 20 submissions
          }
        }
      } catch (fetchError) {
        console.log('Could not fetch real contacts, using mock data:', fetchError.message);
      }
    }

    // Fallback to mock data if Google Sheets integration fails
    const mockContacts = [
      {
        timestamp: new Date().toISOString(),
        fullName: 'John Doe',
        firstName: 'John',
        lastName: 'Doe',
        email: 'john@example.com',
        phone: '+91 9876543210',
        interest: 'Cyber Security',
        subject: 'Training Inquiry',
        message: 'I am interested in your cyber security training programs.',
        newsletter: 'Yes'
      },
      {
        timestamp: new Date(Date.now() - 86400000).toISOString(),
        fullName: 'Jane Smith',
        firstName: 'Jane',
        lastName: 'Smith',
        email: 'jane@example.com',
        phone: '+91 9876543211',
        interest: 'IoT Training',
        subject: 'Course Information',
        message: 'Please provide more details about IoT training courses.',
        newsletter: 'No'
      },
      {
        timestamp: new Date(Date.now() - 172800000).toISOString(),
        fullName: 'Bob Johnson',
        firstName: 'Bob',
        lastName: 'Johnson',
        email: 'bob@example.com',
        phone: '+91 9876543212',
        interest: 'STEM Education',
        subject: 'School Partnership',
        message: 'We are interested in implementing STEM labs in our school.',
        newsletter: 'Yes'
      }
    ];

    res.json(mockContacts);
  } catch (error) {
    console.error('Error fetching contacts:', error);
    res.status(500).json({ error: 'Failed to fetch contacts' });
  }
});

app.get('/api/admin/enquiries', requireAuth, async (req, res) => {
  try {
    // Try to fetch real enquiry data from Google Sheets
    const appsScriptUrl = process.env.APPS_SCRIPT_URL;

    if (appsScriptUrl) {
      try {
        const enquiriesUrl = appsScriptUrl.replace('/exec', '/exec?action=getEnquiries');

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 15000);

        const response = await fetch(enquiriesUrl, {
          method: 'GET',
          headers: {
            'User-Agent': 'Yuvabot-Admin/1.0',
            'Authorization': req.headers.authorization
          },
          signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (response.ok) {
          const data = await response.json();
          if (data.success && data.data) {
            return res.json(data.data.slice(-20));
          }
        }
      } catch (fetchError) {
        console.log('Could not fetch real enquiries, using mock data:', fetchError.message);
      }
    }

    // Fallback to mock enquiry data
    const mockEnquiries = [
      {
        timestamp: new Date().toISOString(),
        name: 'John Smith',
        email: 'john@company.com',
        phone: '+91 9876543210',
        company: 'Tech Solutions Ltd',
        serviceInterest: 'IoT Solutions',
        budgetRange: '₹2,00,000 - ₹5,00,000',
        timeline: '3-6 months',
        message: 'We are looking for IoT solutions for our manufacturing facility.',
        source: 'Website'
      },
      {
        timestamp: new Date(Date.now() - 86400000).toISOString(),
        name: 'Sarah Johnson',
        email: 'sarah@university.edu',
        phone: '+91 9876543211',
        company: 'State University',
        serviceInterest: 'STEM Education',
        budgetRange: '₹5,00,000 - ₹10,00,000',
        timeline: '6-12 months',
        message: 'We want to set up a STEM lab for our engineering department.',
        source: 'Website'
      }
    ];

    res.json(mockEnquiries);
  } catch (error) {
    console.error('Error fetching enquiries:', error);
    res.status(500).json({ error: 'Failed to fetch enquiries' });
  }
});

app.get('/api/admin/newsletter', requireAuth, async (req, res) => {
  try {
    // Mock newsletter data
    const mockSubscribers = [
      {
        email: 'user1@example.com',
        timestamp: new Date().toISOString()
      },
      {
        email: 'user2@example.com',
        timestamp: new Date(Date.now() - 86400000).toISOString()
      }
    ];

    res.json(mockSubscribers);
  } catch (error) {
    console.error('Error fetching newsletter subscribers:', error);
    res.status(500).json({ error: 'Failed to fetch subscribers' });
  }
});

app.get('/api/admin/students', requireAuth, async (req, res) => {
  try {
    // Mock student registration data
    const mockStudents = [
      {
        timestamp: new Date().toISOString(),
        name: 'Alice Johnson',
        email: 'alice@example.com',
        phone: '+91 9876543212',
        qualification: 'B.Tech',
        branch: 'Electronics'
      }
    ];

    res.json(mockStudents);
  } catch (error) {
    console.error('Error fetching students:', error);
    res.status(500).json({ error: 'Failed to fetch students' });
  }
});

app.get('/api/admin/colleges', requireAuth, async (req, res) => {
  try {
    // Mock college registration data
    const mockColleges = [
      {
        timestamp: new Date().toISOString(),
        collegeName: 'ABC Engineering College',
        contactPerson: 'Dr. Robert Wilson',
        designation: 'Placement Officer',
        email: 'placements@abc.edu',
        phone: '+91 9876543213',
        driveType: 'Both Internship & Job',
        studentCount: '150'
      }
    ];

    res.json(mockColleges);
  } catch (error) {
    console.error('Error fetching colleges:', error);
    res.status(500).json({ error: 'Failed to fetch colleges' });
  }
});

// ==================== SECURITY LOGGING ====================

// Security event logging function
const logSecurityEvent = (event, details) => {
  const timestamp = new Date().toISOString();
  const logEntry = {
    timestamp,
    event,
    details,
    ip: details.ip || 'unknown',
    userAgent: details.userAgent || 'unknown',
    path: details.path || 'unknown'
  };

  console.log(`[SECURITY] ${event}:`, JSON.stringify(logEntry, null, 2));

  // In production, you would write to a security log file or SIEM system
  // Example: write to file, send to logging service, etc.
};

// Request logging middleware with security focus
app.use((req, res, next) => {
  const start = Date.now();

  // Log security-relevant requests
  if (req.path.startsWith('/api/') || req.path.includes('admin')) {
    logSecurityEvent('API_ACCESS', {
      method: req.method,
      path: req.path,
      ip: req.ip,
      userAgent: req.get('User-Agent'),
      timestamp: new Date().toISOString()
    });
  }

  // Log response
  res.on('finish', () => {
    const duration = Date.now() - start;

    if (res.statusCode >= 400) {
      logSecurityEvent('ERROR_RESPONSE', {
        method: req.method,
        path: req.path,
        statusCode: res.statusCode,
        duration,
        ip: req.ip,
        userAgent: req.get('User-Agent')
      });
    }

    // Log potential attacks
    if (req.path.includes('<script>') || req.path.includes('javascript:') ||
        req.body && JSON.stringify(req.body).includes('<script>')) {
      logSecurityEvent('POTENTIAL_XSS', {
        method: req.method,
        path: req.path,
        body: req.body,
        ip: req.ip
      });
    }
  });

  next();
});

// ==================== SECURE ERROR HANDLING ====================

// Global error handler
app.use((err, req, res, next) => {
  let errorResponse = {
    success: false,
    error: 'Internal server error'
  };

  // Log the full error for debugging (never expose to client)
  console.error('Unhandled error:', {
    message: err.message,
    stack: err.stack,
    url: req.url,
    method: req.method,
    ip: req.ip,
    userAgent: req.get('User-Agent'),
    timestamp: new Date().toISOString()
  });

  // Log security events
  if (err.message.includes('SQL') || err.message.includes('injection')) {
    logSecurityEvent('POTENTIAL_INJECTION', {
      error: err.message,
      path: req.path,
      ip: req.ip
    });
  }

  // Don't leak sensitive information
  if (err.name === 'ValidationError') {
    errorResponse.error = 'Invalid input data';
    errorResponse.details = err.errors;
  } else if (err.name === 'CastError') {
    errorResponse.error = 'Invalid data format';
  } else if (err.code === 11000) {
    errorResponse.error = 'Duplicate entry';
  }

  // Send appropriate status code
  const statusCode = err.statusCode || err.status || 500;
  res.status(statusCode).json(errorResponse);
});

// 404 handler
app.use((req, res) => {
  logSecurityEvent('NOT_FOUND', {
    method: req.method,
    path: req.path,
    ip: req.ip,
    userAgent: req.get('User-Agent')
  });

  res.status(404).json({
    success: false,
    error: 'Resource not found'
  });
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (err, promise) => {
  console.error('Unhandled Rejection:', err);
  logSecurityEvent('UNHANDLED_REJECTION', {
    error: err.message,
    stack: err.stack
  });

  // Close server & exit process
  server.close(() => {
    process.exit(1);
  });
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
  logSecurityEvent('UNCAUGHT_EXCEPTION', {
    error: err.message,
    stack: err.stack
  });

  process.exit(1);
});

// Start server
// For Vercel deployment - export the app
if (process.env.VERCEL) {
  module.exports = app;
} else {
  // Local development
  app.listen(PORT, () => {
    console.log(`🚀 Yuvabot Website Server running on port ${PORT}`);
    console.log(`📍 Local: http://localhost:${PORT}`);
    console.log(`🔧 Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`📧 Apps Script URL: ${process.env.APPS_SCRIPT_URL ? 'Configured' : 'Not configured'}`);
  });
}

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  process.exit(0);
});

